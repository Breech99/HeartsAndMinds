class CfgSounds {
	class btc_sound_allahu_akbar {
		name = "btc_sound_allahu_akbar";
		sound[] = {"core\sounds\allahu_akbar.ogg", 15, 1};
		titles[] = {};
	};
};