class Extended_PreInit_EventHandlers {
    class btc_hearts_and_minds {
        init = "call compile preprocessFile 'core\def\mission.sqf';call compile preprocessFile 'core\fnc\compile.sqf';";
    };
};