class CfgFunctions {
    class btc {
        class misc {
            class eh_veh_init {
                file = "core\fnc\eh\veh_init.sqf";//preInit = 1;
            };
        };
    };
	#include "..\..\CHVD\CfgFunctions.hpp"
	#include "..\..\functions\CfgFunctions.hpp"
};  